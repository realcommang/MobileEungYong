package ddwu.mobile.lbs.ma02_20190962;

import android.content.Context;
import android.net.ConnectivityManager;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Comment.class}, version = 1)
public abstract class CommentDB extends RoomDatabase {
    public abstract CommentDao commentDao();

    private static volatile CommentDB INSTANCE;

    static CommentDB getDatabase(final Context context) {
        if(INSTANCE == null) {
            synchronized (CommentDB.class) {
                if(INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    CommentDB.class, "comment")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
