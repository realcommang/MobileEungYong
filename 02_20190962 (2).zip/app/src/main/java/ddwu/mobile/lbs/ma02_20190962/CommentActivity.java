package ddwu.mobile.lbs.ma02_20190962;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class CommentActivity extends AppCompatActivity {

    final int REQ_PERMISSION_CODE = 100;
    final String TAG = "CommentActivity";

    CommentDB commentDB;
    CommentDao commentDao;
    Comment comm;
    WiFi wifi;

    private final CompositeDisposable mDisposable = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment);

        commentDB = CommentDB.getDatabase(this);
        commentDao = commentDB.commentDao();

        Intent intent = getIntent();
        wifi = (WiFi) intent.getSerializableExtra("comment");

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                //등록
                //검색 정보 읽음
                EditText et = (EditText)findViewById(R.id.editTextTextPersonName3);
                EditText et1 = (EditText) findViewById(R.id.editTextTextMultiLine);

                if(et.getText().toString().length() == 0)
                    Toast.makeText(CommentActivity.this, "비번을 입력해주세요.", Toast.LENGTH_SHORT).show();
                else if(et1.getText().toString().length() == 0) {
                    Toast.makeText(CommentActivity.this, "댓글을 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
                else{
                    String input = et.getText().toString();
                    String line = et1.getText().toString();

                    System.out.println(input);

                    Single<Long> insertResult = commentDao.insertComment(new Comment(input, wifi.getAdd_1(),
                            wifi.getAdd_2(), wifi.getLAT(), wifi.getLNT(), line));

                    mDisposable.add(
                            insertResult.subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(result -> Toast.makeText(CommentActivity.this, "즐겨찾기 등록 완료.", Toast.LENGTH_SHORT).show(),
                                            throwable -> Log.d(TAG, "error"))
                    );
                }

                break;
            case R.id.button2:

                EditText et2 = (EditText)findViewById(R.id.editTextTextPersonName3);

                if(et2.getText().toString().length() == 0) {
                    Toast.makeText(CommentActivity.this, "댓글을 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent intent3 = new Intent(v.getContext(), CommentsActivity.class);
                    intent3.putExtra("pw", et2.getText().toString());
                    startActivity(intent3);
                }

                break;
        }
    }
}
