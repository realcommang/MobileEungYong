package ddwu.mobile.lbs.ma02_20190962;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapActivity extends AppCompatActivity {

    ArrayList<WiFi> wifis;
    private GoogleMap mGoogleMap;

    private Marker mPoiMarker;
    ArrayList<Marker> markers = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wifi_map);

        wifis = (ArrayList<WiFi>) getIntent().getSerializableExtra("wifis");

        SupportMapFragment mapFragment
                = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(mapReadyCallback);
    }

    OnMapReadyCallback mapReadyCallback = new OnMapReadyCallback() {
        @Override
        public void onMapReady(@NonNull GoogleMap googleMap) {
            mGoogleMap = googleMap;

            for (int i = 0; i < wifis.size(); i++) {
                LatLng latLng = new LatLng(Double.parseDouble(wifis.get(i).getLAT()), Double.parseDouble(wifis.get(i).getLAT()));
                if (i == 0) mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));

                MarkerOptions markerOptions = new MarkerOptions()
                        .position(latLng)
                        .title(wifis.get(i).getAdd_1())
                        .snippet(wifis.get(i).toString())
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));

                mPoiMarker = mGoogleMap.addMarker(markerOptions);
                markers.add(mPoiMarker);
            }

           mPoiMarker.showInfoWindow();
        }
    };
}
