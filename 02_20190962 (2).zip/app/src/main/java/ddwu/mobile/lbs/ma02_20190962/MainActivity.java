package ddwu.mobile.lbs.ma02_20190962;

import static android.app.PendingIntent.getActivity;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    final String TAG = "MainActivity";

    final int REQ_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_myloc:

                Intent intent = new Intent(getApplicationContext(), ResultActivity.class);
                intent.putExtra("code", 1);
                startActivity(intent);

                break;
            case R.id.btn_search:

                Intent intent1 = new Intent(getApplicationContext(), ResultActivity.class);
                intent1.putExtra("code", 2);
                startActivity(intent1);

                break;
        }
    }
}