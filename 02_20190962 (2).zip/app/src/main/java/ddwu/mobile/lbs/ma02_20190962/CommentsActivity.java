package ddwu.mobile.lbs.ma02_20190962;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class CommentsActivity extends Activity {

    String pw;
    CommentDB commentDB;
    CommentDao commentDao;

    ListView lvList;
    ArrayAdapter<Comment> adapter;

    private final CompositeDisposable mDisposable = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.comments);

        commentDB = CommentDB.getDatabase(this);
        commentDao = commentDB.commentDao();

        lvList = findViewById(R.id.comments);
        adapter = new ArrayAdapter<Comment>(this, android.R.layout.simple_list_item_1, new ArrayList<Comment>());
        lvList.setAdapter(adapter);

        Intent intent = getIntent();
        pw = intent.getStringExtra("pw");

        Flowable<List<Comment>> resultComment = commentDao.getComment(pw);

        mDisposable.add(
                resultComment.subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(comments -> {
                                    adapter.clear();
                                    adapter.addAll(comments);
                                },
                                throwable -> Toast.makeText(this, "아직 즐겨찾기가 없어요.", Toast.LENGTH_SHORT).show()));

        lvList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                Completable delComment = commentDao.deleteComment((Comment) lvList.getAdapter().getItem(position));

                mDisposable.add(
                        delComment.subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe( () -> {
                                    Toast.makeText(CommentsActivity.this, "삭제 완료", Toast.LENGTH_SHORT); },
                                        throwable -> Toast.makeText(CommentsActivity.this, "삭제 실패.", Toast.LENGTH_SHORT).show()));

                return true;

            }
        });

    }
}
