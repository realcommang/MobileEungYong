package ddwu.mobile.lbs.ma02_20190962;

import java.io.Serializable;

public class WiFi implements Serializable {

    private String add_1; //도로명
    private String add_2; //상세
    private String LAT;
    private String LNT;

    public String getAdd_1() {
        return add_1;
    }

    public void setAdd_1(String add_1) {
        this.add_1 = add_1;
    }

    public String getAdd_2() {
        return add_2;
    }

    public void setAdd_2(String add_2) {
        this.add_2 = add_2;
    }

    public String getLAT() {
        return LAT;
    }

    public void setLAT(String LAT) {
        this.LAT = LAT;
    }

    public String getLNT() {
        return LNT;
    }

    public void setLNT(String LNT) {
        this.LNT = LNT;
    }

    @Override
    public String toString() {
        return add_1 + ' ' + add_2 + '\n';
    }
}
