package ddwu.mobile.lbs.ma02_20190962;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;
import io.reactivex.Single;

@Dao
public interface CommentDao {

    @Insert
    Single<Long> insertComment(Comment comment);

    @Query("SELECT * FROM comment WHERE pw = :pw")
    Flowable<List<Comment>> getComment(String pw);

    @Delete
    Completable deleteComment(Comment comment);
}
