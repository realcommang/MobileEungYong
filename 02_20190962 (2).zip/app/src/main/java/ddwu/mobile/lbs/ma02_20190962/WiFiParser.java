package ddwu.mobile.lbs.ma02_20190962;

import android.location.Location;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;

public class WiFiParser {

    private enum TagType {NONE, ADD1, ADD2, LAT, LNT};

    private final static String ROW_TAG = "row";
    private final static String ADD1_TAG = "X_SWIFI_ADRES1";
    private final static String ADD2_TAG = "X_SWIFI_ADRES2";
    private final static String LAT_TAG = "LAT";
    private final static String LNT_TAG = "LNT";

    private XmlPullParser parser;

    Location location;
    String lat;
    String lnt;

    public WiFiParser() {
        XmlPullParserFactory factory = null;
        try {
            factory = XmlPullParserFactory.newInstance();
            parser = factory.newPullParser();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<WiFi> parse(String xml) {

        ArrayList<WiFi> resultList = new ArrayList<>();

        WiFi wifi = null;
        TagType tagType = TagType.NONE;

        try{
            parser.setInput(new StringReader(xml));
            int eventType = parser.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        String tag = parser.getName();
                        if(tag.equals(ROW_TAG)) {
                            wifi = new WiFi();
                        } else if(tag.equals(ADD1_TAG)) {
                            tagType = TagType.ADD1;
                        } else if(tag.equals(ADD2_TAG)) {
                            tagType = TagType.ADD2;
                        } else if(tag.equals(LAT_TAG)) {
                            tagType = TagType.LAT;
                        } else if(tag.equals(LNT_TAG)) {
                            tagType = TagType.LNT;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if(parser.getName().equals(ROW_TAG)) {
                            resultList.add(wifi);
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch (tagType) {
                            case ADD1:
                                if(wifi != null) {
                                    wifi.setAdd_1(parser.getText());
                                }
                                break;
                            case ADD2:
                                wifi.setAdd_2(parser.getText());
                                break;
                            case LAT:
                                wifi.setLAT(parser.getText());
                                break;
                            case LNT:
                                wifi.setLNT(parser.getText());
                                break;
                        }
                        tagType = TagType.NONE;
                        break;
                }
                eventType = parser.next();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }

        return resultList;
    }
}
