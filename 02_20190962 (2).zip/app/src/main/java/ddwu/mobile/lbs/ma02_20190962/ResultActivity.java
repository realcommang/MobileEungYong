package ddwu.mobile.lbs.ma02_20190962;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.reactivex.disposables.CompositeDisposable;

public class ResultActivity extends AppCompatActivity {

    final int REQ_PERMISSION_CODE = 100;
    final String TAG = "ResultActivity";

    ListView lvList;

    FusedLocationProviderClient flpClient;
    Location mLastLocation;

    String apiAddress;
    StringBuilder urlBuilder;
    Address address;

    ArrayList<WiFi> wifis;
    ArrayAdapter<WiFi> resultList;
    WiFiParser parser;
    int code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wifi_result);

        lvList = findViewById(R.id.results);

        wifis = new ArrayList();
        resultList = new ArrayAdapter<WiFi>(this, android.R.layout.simple_list_item_1, wifis);
        lvList.setAdapter(resultList);

        apiAddress = getResources().getString(R.string.api_url);
        parser = new WiFiParser();      // 모의 parser 생성
        flpClient = LocationServices.getFusedLocationProviderClient(this);
        urlBuilder = new StringBuilder();

        Intent intent = getIntent();
        code = intent.getIntExtra("code", 0);

        if (code == 1) { //내위치로 검색
            if (!isOnline()) {
                Toast.makeText(ResultActivity.this, "네트워크를 사용 설정해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            //현재위치
            checkPermission();
            getLastLocation();
        }
        else if (code == 2) {
            if (!isOnline()) {
                Toast.makeText(ResultActivity.this, "네트워크를 사용 설정해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            checkPermission();
        }

        lvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                WiFi WFComm = ((WiFi) lvList.getAdapter().getItem(position));

                Intent intent2 = new Intent(view.getContext(), CommentActivity.class);
                intent2.putExtra("comment", WFComm);
                startActivity(intent2);

            }
        });
    }

    LocationCallback mLocCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            for (Location loc : locationResult.getLocations()) {
                double lat = loc.getLatitude();
                double lng = loc.getLongitude();
                mLastLocation = loc;
            }
        }
    };

    private LocationRequest getLocationRequest() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return locationRequest;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_input:

                //검색 정보 읽음
                EditText et = (EditText)findViewById(R.id.sample_EditText);

                if(et.getText().toString().length() == 0)
                    Toast.makeText(ResultActivity.this, "주소를 입력해주세요.", Toast.LENGTH_SHORT).show();
                else{
                    String input = et.getText().toString();

                    //형식에 맞지 않으면 : 00구
                    if(!input.matches("(.*)구(.*)")) {
                      Toast.makeText(ResultActivity.this, "자치구 입력해주세요", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        System.out.println(input);
                        new WiFiAsyncTask().execute(apiAddress, input);
                    }
                }
                break;
            case R.id.btn_go_map:

                if(wifis.isEmpty())
                    Toast.makeText(ResultActivity.this, "주소를 입력해주세요.", Toast.LENGTH_SHORT).show();
                else {

                    ArrayList<WiFi> wiFiArrayList = new ArrayList();
                    for (int i = 0; i < wifis.size(); i++) {
                        wiFiArrayList.add(wifis.get(i));
                    }

                    Intent intent = new Intent(this, MapActivity.class);
                    intent.putExtra("wifis", wiFiArrayList);
                    startActivity(intent);
                }

                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        flpClient.removeLocationUpdates(mLocCallback);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQ_PERMISSION_CODE:
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "위치권한 획득 완료", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "위치권한 미획득", Toast.LENGTH_SHORT).show();
                }
        }
    }

    private void checkPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED) {
            // 권한이 있을 경우 수행할 동작
            Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();
        } else {
            // 권한 요청
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQ_PERMISSION_CODE);
        }
    }


    private void getLastLocation() {
        flpClient.getLastLocation().addOnSuccessListener(
                new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            double latitude = location.getLatitude();
                            double longitude = location.getLongitude();

                            mLastLocation = location;

                            if(code == 1) { //내 위치로 검색
                                LatLng latLng = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
                                executeGeocoding(latLng); //주소 얻기
                            }

                        } else {
                            Toast.makeText(ResultActivity.this, "No location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        flpClient.getLastLocation().addOnFailureListener(
                new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, "Unknown");
                    }
                }
        );

    }

    private void executeGeocoding(LatLng latLng) {
        if (Geocoder.isPresent()) {
            Toast.makeText(this, "Run Geocoder", Toast.LENGTH_SHORT).show();
            if (latLng != null)  new ResultActivity.GeoTask().execute(latLng);
        } else {
            Toast.makeText(this, "No Geocoder", Toast.LENGTH_SHORT).show();
        }
    }

    class GeoTask extends AsyncTask<LatLng, Void, List<Address>> {
        Geocoder geocoder = new Geocoder(ResultActivity.this, Locale.getDefault());
        @Override
        protected List<Address> doInBackground(LatLng... latLngs) {
            List<Address> addresses = null;
            try {
                addresses = geocoder.getFromLocation(latLngs[0].latitude,
                        latLngs[0].longitude, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return addresses;
        }

        @Override
        protected void onPostExecute(List<Address> addresses) {
            if (addresses != null) {
                address = addresses.get(0);
                if(code == 1) {
                    new WiFiAsyncTask().execute(apiAddress, address.getAddressLine(0));
                }
                //Toast.makeText(ResultActivity.this, address.getAddressLine(0), Toast.LENGTH_SHORT).show();
            }
        }
    }

    class WiFiAsyncTask extends AsyncTask<String, Integer, String> {
        ProgressDialog progressDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(ResultActivity.this, "Wait", "Downloading...");
        }

        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            String query = strings[1];
            String region;
            String region1;

            if(code == 1) {
                region = query.split(" ")[2]; //자치구 추출
                region1 = query.split(" ")[3]; //상세위치
            }
            else {
                region = query.split(" ")[0]; //자치구 추출
                region1 = query.split(" ")[1]; //상세위치
            }

            System.out.println(region1);

            String apiURL = null;
            try {
                urlBuilder.append(address);
                urlBuilder.append("/" + URLEncoder.encode(getResources().getString(R.string.api_key),"UTF-8") );
                urlBuilder.append("/" + URLEncoder.encode("xml","UTF-8") );
                urlBuilder.append("/" + URLEncoder.encode("TbPublicWifiInfo","UTF-8"));
                urlBuilder.append("/" + URLEncoder.encode("1","UTF-8"));
                urlBuilder.append("/" + URLEncoder.encode("1000","UTF-8"));
                urlBuilder.append("/" + URLEncoder.encode(region,"UTF-8"));
                urlBuilder.append("/" + URLEncoder.encode(region1,"UTF-8"));

                apiURL = urlBuilder.toString();

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            String result = downloadWiFiContents(apiURL);
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            Log.i(TAG, result);
            progressDlg.dismiss();

            ArrayList<WiFi> parserdList = parser.parse(result);     // 오픈API 결과의 파싱 수행
            //ArrayList<WiFi> parserdList = parser.parse(result, mLastLocation);

            if (parserdList == null || parserdList.size() == 0) {
                Toast.makeText(ResultActivity.this, "No data!", Toast.LENGTH_SHORT).show();
            } else {
                wifis.clear();
                wifis.addAll(parserdList);
                resultList.notifyDataSetChanged();
            }
        }
    }

    /* 네트워크 환경 조사 */
    private boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    /* 주소(address)에 접속하여 문자열 데이터를 수신한 후 반환 */
    protected String downloadWiFiContents(String address) {
        HttpURLConnection conn = null;
        String result = null;

        try {
            URL url = new URL(address);
            conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-type", "application/xml");

            BufferedReader rd;

            if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
                rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else {
                rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }

            rd.close();
            result = sb.toString();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
        }
        return result;
    }

}
