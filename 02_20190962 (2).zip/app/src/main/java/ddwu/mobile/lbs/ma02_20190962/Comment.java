package ddwu.mobile.lbs.ma02_20190962;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "comment")
public class Comment implements Serializable {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    private Long id;
    @ColumnInfo(name = "pw")
    private String pw;
    @ColumnInfo(name = "add_1")
    private String add_1; //도로명
    @ColumnInfo(name = "add_2")
    private String add_2; //상세
    @ColumnInfo(name = "lat")
    private String LAT;
    @ColumnInfo(name = "lnt")
    private String LNT;
    @ColumnInfo(name = "comment")
    private String comment;

    public Comment(String pw, String add_1, String add_2, String LAT, String LNT, String comment) {
        this.pw = pw;
        this.add_1 = add_1;
        this.add_2 = add_2;
        this.LAT = LAT;
        this.LNT = LNT;
        this.comment = comment;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getAdd_1() {
        return add_1;
    }

    public void setAdd_1(String add_1) {
        this.add_1 = add_1;
    }

    public String getAdd_2() {
        return add_2;
    }

    public void setAdd_2(String add_2) {
        this.add_2 = add_2;
    }

    public String getLAT() {
        return LAT;
    }

    public void setLAT(String LAT) {
        this.LAT = LAT;
    }

    public String getLNT() {
        return LNT;
    }

    public void setLNT(String LNT) {
        this.LNT = LNT;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public String toString() {
        return  add_1 + ' ' +
                add_2 +
                ", 댓글 = " + comment + '\n';
    }
}
